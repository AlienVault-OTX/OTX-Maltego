
class OTXSetting:
    
    def __init__(self):
        # This is set to the API key for the user api_example so the transform will work out of the box
        # Please set to your own API key
        self.API_KEY = "766ba1df3ab54db9c0fcbf62ef048c3a04c260e8ca65b6c25346084b7b4719ad"
